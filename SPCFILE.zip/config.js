module.exports = {
  Token: "8398983376:AAHKMaPONcrkQV-1HmPoibVanYbNc0my90U",
  owner: "8523963580",

  //  konfigurasi panel pterodactyl
  domain: "https://",
  ptla: "ptla_fKlGXXOW8dX1", 
  ptlc: "ptlc_byjwYGI"
};